"use client"

import type { Message } from "ai/react"
import type { RefObject } from "react"

interface ChatSection {
  id: string
  userMessage: Message
  assistantMessages: Message[]
}

interface ChatMessagesProps {
  sections: ChatSection[]
  data: any
  onQuerySelect: (query: string) => void
  isLoading: boolean
  chatId: string
  addToolResult: (result: any) => void
  scrollContainerRef: RefObject<HTMLDivElement>
  onUpdateMessage: (messageId: string, newContent: string) => void
  reload: (messageId: string, options?: any) => void
}

export function ChatMessages({
  sections,
  data,
  onQuerySelect,
  isLoading,
  chatId,
  addToolResult,
  scrollContainerRef,
  onUpdateMessage,
  reload,
}: ChatMessagesProps) {
  return (
    <div ref={scrollContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
      {sections.map((section) => (
        <div key={section.id} id={`section-${section.id}`} className="space-y-4">
          {/* User Message */}
          <div className="flex justify-end">
            <div className="bg-blue-500 text-white p-3 rounded-lg max-w-xs lg:max-w-md">
              {section.userMessage.content}
            </div>
          </div>

          {/* Assistant Messages */}
          {section.assistantMessages.map((message) => (
            <div key={message.id} className="flex justify-start">
              <div className="bg-gray-200 text-gray-800 p-3 rounded-lg max-w-xs lg:max-w-md">{message.content}</div>
            </div>
          ))}
        </div>
      ))}

      {isLoading && (
        <div className="flex justify-start">
          <div className="bg-gray-200 text-gray-800 p-3 rounded-lg">
            <div className="animate-pulse">Thinking...</div>
          </div>
        </div>
      )}
    </div>
  )
}
