"use client"

import type React from "react"

import type { Message } from "ai/react"
import type { RefObject } from "react"
import type { Model } from "@/lib/types/models"
import { Button } from "@/components/ui/button"

interface ChatPanelProps {
  input: string
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  handleSubmit: (e: React.FormEvent<HTMLFormElement>) => void
  isLoading: boolean
  messages: Message[]
  setMessages: (messages: Message[]) => void
  stop: () => void
  query?: string
  append: (message: { role: string; content: string }) => void
  models?: Model[]
  showScrollToBottomButton: boolean
  scrollContainerRef: RefObject<HTMLDivElement>
}

export function ChatPanel({
  input,
  handleInputChange,
  handleSubmit,
  isLoading,
  messages,
  setMessages,
  stop,
  query,
  append,
  models,
  showScrollToBottomButton,
  scrollContainerRef,
}: ChatPanelProps) {
  const scrollToBottom = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight
    }
  }

  return (
    <div className="border-t bg-white p-4">
      {showScrollToBottomButton && (
        <div className="mb-4 flex justify-center">
          <Button onClick={scrollToBottom} variant="outline" size="sm">
            Scroll to bottom
          </Button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Type your message..."
          className="flex-1 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading}
        />

        {isLoading ? (
          <Button type="button" onClick={stop} variant="outline">
            Stop
          </Button>
        ) : (
          <Button type="submit" disabled={!input.trim()}>
            Send
          </Button>
        )}
      </form>
    </div>
  )
}
