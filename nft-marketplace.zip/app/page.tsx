"use client"

import NFTMarketplace from "../nft-marketplace"

export default function Page() {
  return <NFTMarketplace />
}
