export const CHAT_ID = "default-chat-id"
