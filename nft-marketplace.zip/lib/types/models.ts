export interface Model {
  id: string
  name: string
  provider: string
  maxTokens?: number
}
